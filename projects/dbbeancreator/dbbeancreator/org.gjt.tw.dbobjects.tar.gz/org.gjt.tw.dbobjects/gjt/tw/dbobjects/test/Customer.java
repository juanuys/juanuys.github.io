package org.gjt.tw.dbobjects.test;

/*
 * DB Objects
 *
 * Copyright (C) 2000 Tim Wellhausen <Tim.Wellhausen@gmx.de>
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 *
 * See the COPYING file located in the top-level-directory of
 * the archive of this library for complete text of license.
 */

/*
 * Project  : DB Objects
 * Package  : dbobjects.test
 * Class    : Customer
 * Purpose  : Test object containing data about a customer
 * Created  : March 15, 2000
 * Modified : August 21, 2000
 */

import org.gjt.tw.dbobjects.*;
import java.util.*;

/**
 * Test class containing data about a customer. The id of the customer is the unique key 
 * of this object.
 *
 * @author Tim Wellhausen, <a href="mailto:Tim.Wellhausen@gmx.de">Tim.Wellhausen@gmx.de</a>.
 * @version 0.29
 */
public class Customer extends StorableObject {
	private static ObjectMapping mapping;
	private String name;
	private String password;
	private long currentAddressId;
	private java.sql.Date created;
	private long id;
/**
 * TestObject constructor comment.
 */
public Customer() {
	super();
	name = "";
	password = "";
	currentAddressId = -1;
	created = new java.sql.Date (Calendar.getInstance().getTime().getTime());
}
/**
 * This method was created in VisualAge.
 * @return dbobjects.test.Address[]
 */
public Address[] getAddressList () throws DatabaseException, ObjectException {
	CustomerAddress[] ca = CustomerAddress.getByCustomer (this);
	
	Vector aVector = new Vector ();
	for (int i = 0; i < ca.length; i++)
		aVector.addElement (Address.getById (ca[i].getAddressId()));
	Address[] addresses = new Address [aVector.size ()];
	aVector.copyInto (addresses);

	return addresses;
}
/**
 * Searches for a customer in the database given the name of a customer. Upon success a Customer
 * object is returned.
 *
 * @return Customer object if it exists - null otherwise.
 * @param name name of a customer
 */
public static Customer getByName (String name) throws DatabaseException, ObjectException {
	StorableObject[] objects = DBManager.getByField (mapping, "name", name);
	if (objects == null)
		return null;
	else
		return (Customer) objects[0];
}
/**
 * This method was created in VisualAge.
 * @return java.sql.Date
 */
public java.sql.Date getCreated() {
	return created;
}
/**
 * This method was created in VisualAge.
 * @return databasemanagement.test.Address
 */
public Address getCurrentAddress () throws DatabaseException, ObjectException {
	return Address.getById (currentAddressId);
}
/**
 * This method was created in VisualAge.
 * @return long
 */
public long getCurrentAddressId() {
	return currentAddressId;
}
/**
 * This method was created in VisualAge.
 * @return long
 */
public long getId() {
	return id;
}
/**
 * Returns object mapping.
 *
 * @return databasemanagement2.ObjectMapping
 */
protected ObjectMapping getMapping() {
	if (mapping == null)
		mapping = new ObjectMapping ();
	return mapping;
}
/**
 * Returns name of customer.
 *
 * @return java.lang.String
 */
public String getName() {
	return name;
}
/**
 * Returns password of customer.
 *
 * @return java.lang.String
 */
public String getPassword() {
	return password;
}
/**
 * Initialization of object mapping. Has to be called once before first use.
 */
public static void init () throws ObjectException, IncompleteDefinitionException {
	mapping = new ObjectMapping ();
	mapping.setTableName ("customer");
	mapping.setObjectClass (Customer.class);
	mapping.addField ("id", Long.TYPE, "id");
	mapping.addField ("name", String.class, "customer_name");
	mapping.addField ("password", String.class, "customer_password");
	mapping.addField ("currentAddressId", Long.TYPE, "current_address");
	mapping.addField ("created", java.sql.Date.class, "created");
	mapping.setKeyField ("id");
	mapping.useMySQLAutoIncrement (true);
	mapping.prepareSQLStatements ();
}
/**
 * This method was created in VisualAge.
 * @param newValue java.sql.Date
 */
public void setCreated(java.sql.Date newValue) {
	this.created = newValue;
}
/**
 * This method was created in VisualAge.
 * @param address databasemanagement.test.Address
 */
public void setCurrentAddress (Address address) {
	currentAddressId = address.getId ();
}
/**
 * This method was created in VisualAge.
 * @param newValue long
 */
public void setCurrentAddressId(long newValue) {
	this.currentAddressId = newValue;
}
/**
 * This method was created in VisualAge.
 * @param newValue long
 */
public void setId(long newValue) {
	this.id = newValue;
}
/**
 * Sets name of customer.
 *
 * @param newValue java.lang.String
 */
public void setName(String newValue) {
	this.name = newValue;
}
/**
 * Sets password of customer.
 *
 * @param newValue java.lang.String
 */
public void setPassword(String newValue) {
	this.password = newValue;
}
}
