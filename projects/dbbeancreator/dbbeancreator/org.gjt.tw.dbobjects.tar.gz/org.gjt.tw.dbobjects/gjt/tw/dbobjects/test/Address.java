package org.gjt.tw.dbobjects.test;

/*
 * DB Objects
 *
 * Copyright (C) 2000 Tim Wellhausen <Tim.Wellhausen@gmx.de>
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 *
 * See the COPYING file located in the top-level-directory of
 * the archive of this library for complete text of license.
 */

/**
 * Project  : DB Objects
 * Package  : org.gjt.tw.dbobjects.test
 * Class    : Address
 * Purpose  : Test object containing data about an address
 * Created  : March 25, 2000
 * Modified : August 21, 2000
 */

import org.gjt.tw.dbobjects.*;

/**
 * Test class containing data of an address. ID is the primary key of this object. The id is
 * created by MySQL's auto_increment feature.
 *
 * @author Tim Wellhausen, <a href="mailto:Tim.Wellhausen@gmx.de">Tim.Wellhausen@gmx.de</a>.
 * @version 0.29
 */
public class Address extends StorableObject {
	private static ObjectMapping mapping;
	private long id;
	private String city;
	private String zip;
	private String country;
/**
 * Address constructor comment.
 */
public Address() {
	super();
	city = "";
	zip = "";
	country = "";
}
/**
 * This method was created in VisualAge.
 * @return databasemanagement.test.Address
 * @param addressId long
 */
public static Address getById (long addressId) throws DatabaseException, ObjectException {
	StorableObject[] objects = DBManager.getByField (mapping, "id", new Long (addressId));
	if (objects == null)
		return null;
	else
		return (Address) objects[0];
}
/**
 * Returns name of the city.
 *
 * @return java.lang.String
 */
public String getCity() {
	return city;
}
/**
 * Returns name of the country.
 *
 * @return java.lang.String
 */
public String getCountry() {
	return country;
}
/**
 * Returns values of id.
 *
 * @return long
 */
public long getId() {
	return id;
}
/**
 * Returns object mapping.
 *
 * @return databasemanagement.ObjectMapping
 */
protected ObjectMapping getMapping() {
	if (mapping == null)
		mapping = new ObjectMapping ();
	return mapping;
}
/**
 * Returns zip code as string.
 *
 * @return java.lang.String
 */
public String getZip() {
	return zip;
}
/**
 * Initialization of object mapping. Has to be called once before first use.
 */
public static void init () throws ObjectException, IncompleteDefinitionException {
	mapping = new ObjectMapping ();
	mapping.setTableName ("address");
	mapping.setObjectClass (Address.class);
	mapping.addField ("id", Long.TYPE, "id");
	mapping.addField ("city", String.class, "city");
	mapping.addField ("zip", String.class, "zipcode");
	mapping.addField ("country", String.class, "country");
	mapping.setKeyField ("id");
	mapping.useMySQLAutoIncrement (true);
	mapping.prepareSQLStatements ();
}
/**
 * Sets name of the city.
 *
 * @param newValue java.lang.String
 */
public void setCity(String newValue) {
	this.city = newValue;
}
/**
 * Sets name of the city.
 *
 * @param newValue java.lang.String
 */
public void setCountry(String newValue) {
	this.country = newValue;
}
/**
 * Sets value of id. This is called automatically when the object is inserted into the databse
 * for the first time.
 *
 * @param newValue long
 */
public void setId(long newValue) {
	this.id = newValue;
}
/**
 * Sets the value of the zip code.
 *
 * @param newValue java.lang.String
 */
public void setZip(String newValue) {
	this.zip = newValue;
}
}
