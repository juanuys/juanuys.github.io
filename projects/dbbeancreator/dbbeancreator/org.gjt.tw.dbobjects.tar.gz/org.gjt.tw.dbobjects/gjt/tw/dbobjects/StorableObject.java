package org.gjt.tw.dbobjects;

/*
 * DB Objects
 *
 * Copyright (C) 2000 Tim Wellhausen <Tim.Wellhausen@gmx.de>
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 *
 * See the COPYING file located in the top-level-directory of
 * the archive of this library for complete text of license.
 */

/*
 * Project  : DB Objects
 * Package  : org.gjt.tw.dbobjects
 * Class    : StorableObject
 * Purpose  : This class will be extended by every class containing data 
 *            that should be stored in a database.
 * Created  : December 19, 1999
 * Modified : August 21, 2000
 *
 * @author Tim Wellhausen
 * @version 0.29
 */
import java.lang.reflect.*;
import org.w3c.dom.*;

/**
 * Every class that you want to store in the database using the mechanism provided by
 * this package has to extend this abstract class.
 * <p>
 * Unfortunately, it is possible to extend the class and forget to implement important
 * methods. This means that although everything compiles it might not work.
 * <p>
 * This is a list of what you have to do when extending this class:
 * <p>
 * First, the constructor of your class needs to call the super constructor. Upon creation
 * of the object, the data is not stored in the database. You have to do this by calling
 * the store()-method explicitly. Before store() is called all objects used by your class 
 * have to be instanciated. Otherwise you will get a NullPointerException while storing.
 * If you add a call to store() to the constructor, store() is called each time an object
 * is retrieved from the database. In most cases this is undisirable.
 * <p>
 * Second, you have to provide a get and a set method for each field in the class that
 * you want to store. Example: 
 * <pre>
 *   private String name;
 *
 *   public String getName() {
 *     return name;
 *   }
 *
 *   public void setName (String name) {
 *     this.name = name;
 *   }
 * </pre>
 * <p>
 * Third, you have to implement the method getMapping (). This method always looke the same:
 * <pre>
 *   protected ObjectMapping getMapping() {
 *     if (mapping == null)
 *       mapping = new ObjectMapping ();
 *     return mapping;
 *   }
 * </pre>
 * This method uses an object called mapping. This has to be declared by your class:
 * <pre>
 *   private static ObjectMapping mapping;
 * </pre>
 * <p>
 * Fourth, you have to provide an init () method that initializes the object mapping.
 * This method will look like this:
 * <pre>
 *   public static void init () throws ObjectException, IncompleteDefinitionException {
 *     mapping = new ObjectMapping ();
 *     mapping.setTableName ("customer");
 *     mapping.setObjectClass (Customer.class);
 *     mapping.addField ("id", Long.TYPE, "id");
 *     mapping.addField ("name", String.class, "customer_name");
 *     mapping.setKeyField ("id");
 *     mapping.useMySQLAutoIncrement (true);
 *     mapping.prepareSQLStatements ();
 *   }
 * </pre>
 * <P>
 * Fifth, you might want to implement static methods that allow to retrieve stored objects.
 * Such a method looks like this:
 * <pre>
 *   public static Customer getByName (String name) throws DatabaseException, ObjectException {
 *     StorableObject[] objects = DBManager.getByField (mapping, "name", name);
 *       if (objects == null)
 *         return null;
 *       else
 *         return (Customer) objects[0];
 *   }
 * </pre>
 * <p>
 * For more in depth information please have a look at the examples provided inside
 * the test package. There you will find working examples how to use this package.
 * The best way to create your own new classes is to copy the existing code, get rid
 * of all fields you don't need and extend it by your own code.
 * 
 * @author Tim Wellhausen, <a href="mailto:Tim.Wellhausen@gmx.de">Tim.Wellhausen@gmx.de</a>.
 * @version 0.28
 */
public abstract class StorableObject {
	public boolean isStoredInDatabase;
/**
 * Default Constructor. Sets all values to defaults.
 */
public StorableObject() {
	isStoredInDatabase = false;
}
/**
 * This method creates a new entry in the database. It is never called directly from the
 * application, because if you store an object the database manager decides whether this
 * object has to be inserted or updated.
 */
private void create () throws DatabaseException, ObjectException {

	ObjectMapping mapping = getMapping ();
	try {
		FieldMapping[] fieldMappingList = mapping.getFieldMappingList ();
		int keyFieldNumber = mapping.getKeyFieldNumber ();
		int length = fieldMappingList.length;
		if (mapping.isMySQLAutoIncrementUsed ())
			length--;
		Object[] parameters = new Object [length];

		Object[] emptyArray = {};
		int paramNr = 0;
		int keyNr = keyFieldNumber;
		if (!mapping.isMySQLAutoIncrementUsed ())
			keyNr = -1;
		for (int i = 0; i < fieldMappingList.length; i++) {
			if (i == keyNr)
				continue;
			parameters[paramNr++] = fieldMappingList[i].getMethod.invoke(this, emptyArray);
		}
	
		if (!mapping.isMySQLAutoIncrementUsed ())
			DBManager.insert (mapping, parameters);
		else {
			long key = DBManager.insert (mapping, parameters);
			if (fieldMappingList[keyFieldNumber].fieldClass == Long.TYPE)
				fieldMappingList[keyFieldNumber].setMethod.invoke(this, new Object[] {new Long(key)});
			else if (fieldMappingList[keyFieldNumber].fieldClass == Integer.TYPE)
				fieldMappingList[keyFieldNumber].setMethod.invoke(this, new Object[] {new Integer((int)key)});
		}
	}
	catch (IllegalAccessException e) {
		DBManager.handleException (e);
		throw new ObjectException (e.toString ());
	}
	catch (InvocationTargetException e) {
		DBManager.handleException (e);
		throw new ObjectException (e.toString ());
	}

	isStoredInDatabase = true;
}
/**
 * This method deletes the databse entry of the object. No values of the java object
 * are changed, but the database entry does not exist any more. It is possible to
 * store the object again.
 * 
 * @exception databasemanagement2.DatabaseException The exception description.
 */
public void delete () throws DatabaseException, ObjectException {
	FieldMapping[] fieldMappingList = getMapping().getFieldMappingList ();
	int keyFieldNr = getMapping().getKeyFieldNumber();
	Object[] parameters = new Object [1];

	Object[] emptyArray = {};
	try {
		parameters[0] = fieldMappingList[keyFieldNr].getMethod.invoke(this, emptyArray);
	}
	catch (IllegalAccessException e) {
		DBManager.handleException (e);
		throw new ObjectException (e.toString ());
	}
	catch (InvocationTargetException e) {
		DBManager.handleException (e);
		throw new ObjectException (e.toString ());
	}	
	
	DBManager.delete (getMapping(), parameters);
	isStoredInDatabase = false;
}
/**
 * Returns an XML element that forms a DOM tree representing the data of this object.
 * Only those fields are inserted into the DOM tree that were initialized in the init
 * method.
 *
 * @param document The XML document in whose context the element is created.
 * @return an element containing a DOM tree with all fields
 */
public Element getDomTree (Document document) {
	ObjectMapping mapping = getMapping ();
	FieldMapping[] fields = mapping.getFieldMappingList ();
	
	String classString = mapping.getObjectClass ().toString ();	
	classString = classString.substring (classString.lastIndexOf ('.')+1);	
	
	Element rootElement = document.createElement (classString);

	Element element;
	String text;
	for (int i = 0; i < fields.length; i++) {
		element = document.createElement (fields[i].fieldName);
		
		try {
			Object object = fields[i].getMethod.invoke (this, new Object[]{});
			if (object != null)
				text = object.toString ();
			else
				text = "null";
		}
		catch (Exception e) {
			text = "Error while invoking method "+fields[i].getMethod+" for class "+classString+": "+e;
		}
		element.appendChild (document.createTextNode (text));

		rootElement.appendChild (element);
	}

	return rootElement;
}
/**
 * This method returns the object mapping of the current object. This method is only
 * used internally. But because of implementation issues each class extending StorableObject
 * has to implement this method.
 *
 * The code for this method always looks like this:
 * <pre>
 *   protected ObjectMapping getMapping() {
 *     if (mapping == null)
 *       mapping = new ObjectMapping ();
 *     return mapping;
 *   }
 * </pre>
 *
 * @return databasemanagement.ObjectMapping
 */
protected abstract ObjectMapping getMapping ();
/**
 * This method initializes the class. Each class that extends StorableObject has to
 * implement this class! Upon initialization of your application, the init() method
 * of each of your classes has to be called once.
 */
public static void init () throws ObjectException, IncompleteDefinitionException {
}
/**
 * Prints the values of all mapped fields of the current object to the console.
 */
public void print() {

	try {
		String blanks = "                    ";
		FieldMapping[] fieldMappingList = getMapping().getFieldMappingList ();
		System.out.println ("\n\nPrinting "+this.getClass().toString ()+":\n");
		if (!isStoredInDatabase)
			System.out.println ("This object is not stored in the database!");
			
		for (int i = 0; i < fieldMappingList.length; i++) {
			String name = fieldMappingList[i].fieldName;
			System.out.print (name+blanks.substring (name.length())+" : ");
			System.out.println (fieldMappingList[i].getMethod.invoke (this, new Object[] {}));
		}
	}
	catch (Exception e) {
		System.out.println ("Exception while printing data:");
		System.out.println (e);
	}
	System.out.println ();	
}
/**
 * This method stores the object into the database. From the view of the application there
 * is no difference whether the object has to be inserted or updated.
 */
public void store () throws DatabaseException, ObjectException {
	if (isStoredInDatabase){
            //System.out.println("UPDATE");
		update ();
        }else{
            //System.out.println("INSERT");
		create ();
                
        }
}
/**
 * Returns a string containing the XML representation of the values of the fields stored 
 * in the current object.
 *
 * @return java.lang.String
 */
public String toXML () {
	ObjectMapping mapping = getMapping ();
	FieldMapping[] fields = mapping.getFieldMappingList ();
	String xml;

	String classString = mapping.getObjectClass ().toString ();	
	xml = "<"+classString.substring (classString.lastIndexOf ('.')+1)+">\n";	
	for (int i = 0; i < fields.length; i++) {
		xml += "  <"+fields[i].fieldName+"> ";
		try {
			xml += fields[i].getMethod.invoke (this, new Object[]{});
		}
		catch (Exception e) {
			xml += "Error while invoking get-method for this type!";
		}
		xml += " </"+fields[i].fieldName+">\n";
	}
	
	xml += "</"+mapping.getObjectClass ()+">\n";	
	return xml;
}
/**
 * This method updates an existing entry in the database. It is never called directly from the
 * application, because if you store an object the database manager decides whether this
 * object has to be inserted or updated.
 */
private void update () throws DatabaseException, ObjectException {
	
	FieldMapping[] fieldMappingList = getMapping().getFieldMappingList ();
	int keyFieldNr = getMapping().getKeyFieldNumber();
	
	// Create array containing all parameters for the prepared statement.
	Object[] parameters = new Object [fieldMappingList.length];
	Object[] emptyArray = {};
	try {
		// Set all fields except key field.
		int paramNr = 0;
		for (int i = 0; i < parameters.length; i++) {
			if (i == keyFieldNr)
				continue;
			parameters[paramNr++] = fieldMappingList[i].getMethod.invoke(this, emptyArray);
		}
			
		// Set key field as last parameter of UPDATE string.
		parameters[paramNr] = fieldMappingList[keyFieldNr].getMethod.invoke(this, emptyArray);
	}
	catch (IllegalAccessException e) {
		DBManager.handleException (e);
		throw new ObjectException (e.toString ());
	}
	catch (InvocationTargetException e) {
		DBManager.handleException (e);
		throw new ObjectException (e.toString ());
	}	
	
	DBManager.update (getMapping(), parameters);
}
}
