package org.gjt.tw.dbobjects;
 
import java.sql.*;
import java.util.*;
import java.lang.reflect.*;

public class DBManager {
	//private static DbConnectionBroker dbConnectionBroker;
        private static DbConnectionBroker dbConnectionBroker;
    
	private static boolean initialized = false;

	private static String databaseURLPrefix;
	private static String databaseHost;
	private static String databaseHostPort;
	private static String databaseName;

	private static String driverName;
	private static String username;
        private static java.util.Hashtable hdbs = new java.util.Hashtable();
  private static String password;

  private static DBManager instance;

  private Object[] emptyArray = {};
/**
 * Private Constructor.
 */
private DBManager() {
}


public static boolean execute (String execdbname, String execSQL ) throws DatabaseException {

	try {
		Connection connection = ((DbConnectionBroker)hdbs.get(execdbname.toLowerCase())).getConnection ();

		Statement statement = connection.createStatement();
		statement.execute(execSQL);

		statement.close ();
		((DbConnectionBroker)hdbs.get(execdbname.toLowerCase())).freeConnection (connection);
	}
	catch (SQLException e) {
	  handleException (e);
	  throw new DatabaseException (e.toString ());
	}

	return true;
}


public static ResultSet executeQuery (String execdbname, String execSQL ) throws DatabaseException {
        ResultSet rs =null;
	
	try {
		Connection connection = ((DbConnectionBroker)hdbs.get(execdbname.toLowerCase())).getConnection ();
                if(connection == null)
                    System.out.println("ERROR NO CONNECTION");
             
		Statement statement = connection.createStatement();
                rs = statement.executeQuery(execSQL);
                if(rs == null)
                    System.out.println("RS NULL");
		
		((DbConnectionBroker)hdbs.get(execdbname.toLowerCase())).freeConnection (connection);
	}
	catch (SQLException e) {
            e.printStackTrace();
	  handleException (e);
	  throw new DatabaseException (e.toString ());
	}

	return rs;
}

public static boolean delete (ObjectMapping mapping, Object[] parameters) throws DatabaseException {

	String deleteString = mapping.getSQLDeleteString();
        System.out.println(deleteString);
	try {
		Connection connection = ((DbConnectionBroker)hdbs.get(mapping.getDatabaseName().toLowerCase())).getConnection ();
		
		PreparedStatement statement = prepareStatement (connection, deleteString, parameters);

		ResultSet resultSet;
		statement.executeUpdate ();

		statement.close ();
		((DbConnectionBroker)hdbs.get(mapping.getDatabaseName().toLowerCase())).freeConnection (connection);
	}
	catch (SQLException e) {
	  handleException (e);
	  throw new DatabaseException (e.toString ());
	}

	return true;
}

public static void destroy (String dbname) throws DatabaseException {
	try {
                ((DbConnectionBroker)hdbs.get(dbname.toLowerCase())).destroy(10);
                hdbs.remove(dbname.toLowerCase());
		//dbConnectionBroker.destroy (10);
                
	}
	catch (Exception e) {
	  handleException (e);
	  throw new DatabaseException (e.toString ());
	}
}

public static void destroy () throws DatabaseException {
	try {
                dbConnectionBroker.destroy(10);
                
                
	}
	catch (Exception e) {
	  handleException (e);
	  throw new DatabaseException (e.toString ());
	}
}



private static StorableObject[] doQuery(String queryString, Object[] parameters, ObjectMapping mapping) throws DatabaseException, ObjectException {
       
	Class objectClass = mapping.getObjectClass ();

	Vector vector;
	vector = doQueryVector (queryString, parameters, mapping);
        //System.out.println("in doQuery");
	// Copying vector elements into an array.
	StorableObject[] objects = null;
        if(vector != null)
	if (vector.size () > 0) {
		objects = (StorableObject[]) java.lang.reflect.Array.newInstance (objectClass, vector.size ());
		vector.copyInto (objects);
	}

	return objects;
}


public static String sqlSafeRev(String todo){
     
    
    return todo;
       
    
   
  }

public static String sqlSafe(String todo){
    String tempstr = "";
    if (todo != null){
    if (todo.indexOf("\"") != -1)
        todo = todo.replace('"','\'');
  
    tempstr = todo;
    }else{
        tempstr = "";
    }
    return tempstr;
  }

private static Vector doQueryVector(String queryString, Object[] parameters, ObjectMapping mapping) throws DatabaseException, ObjectException {
	
        StorableObject [] objects = null;
	Class objectClass = mapping.getObjectClass ();
	Vector vector = new Vector ();
	
	try {
		Connection connection = ((DbConnectionBroker)hdbs.get(mapping.getDatabaseName().toLowerCase())).getConnection ();
                
                if(connection == null){
                    
                    System.out.println("NULL CONNECTION :" + hdbs.size() + ":" + mapping.getDatabaseName());
                    return null;
                }
		PreparedStatement statement = prepareStatement (connection, queryString, parameters);
                
		ResultSet resultSet;
		resultSet = statement.executeQuery ();

		StorableObject object = null;
		while (resultSet.next ()) {
			FieldMapping[] fieldMappingList = mapping.getFieldMappingList ();
			object = (StorableObject) objectClass.newInstance ();
			object.isStoredInDatabase = true;
                        
			setFields (object, fieldMappingList, resultSet);
                        
			vector.addElement (object);
		}

		statement.close ();
		((DbConnectionBroker)hdbs.get(mapping.getDatabaseName().toLowerCase())).freeConnection (connection);
	}
	catch (SQLException e) {
	  handleException (e);
	  throw new DatabaseException (e.toString ());
	}
	catch (IllegalAccessException e) {
		handleException (e);
		throw new ObjectException (e.toString ());
	}
	catch (InvocationTargetException e) {
		handleException (e);
		throw new ObjectException (e.toString ());
	}	
	catch (InstantiationException e) {
		handleException (e);
		throw new ObjectException (e.toString ());
	}	

	return vector;
}

public static StorableObject[] getAll (ObjectMapping mapping) throws DatabaseException, ObjectException {
	return getAll (mapping, "");
}

public static StorableObject[] getAll (ObjectMapping mapping, String appendedSqlString) throws DatabaseException, ObjectException {
   
    String sqlString = "SELECT * FROM "+mapping.getTableName()+" "+appendedSqlString+";";
	return doQuery (sqlString, new Object[] {}, mapping);
}

public static Vector getAllVector (ObjectMapping mapping) throws DatabaseException, ObjectException {
	return getAllVector (mapping, "");
}

public static Vector getAllVector (ObjectMapping mapping, String appendedSqlString) throws DatabaseException, ObjectException {
	String sqlString = "SELECT * FROM "+mapping.getTableName()+" "+appendedSqlString+";";
	return doQueryVector (sqlString, new Object[] {}, mapping);
}

public static DbConnectionBroker getBroker () {
	return dbConnectionBroker;
}

public static StorableObject[] getByField (ObjectMapping mapping, String fieldName, Object fieldContent) throws DatabaseException, ObjectException {
	return getByField (mapping, fieldName, fieldContent, "");
}

public static StorableObject[] getByField (ObjectMapping mapping, String fieldName, Object fieldContent, String appendedSqlString) throws DatabaseException, ObjectException {
    
	String columnName = mapping.mapFieldName (fieldName);
	String sqlString = "SELECT * FROM "+mapping.getTableName()+" WHERE "+columnName+" =? "+appendedSqlString+";";
        //System.out.println(sqlString);
        /*return doQuery (sqlString, new Object[] {fieldContent}, mapping);*/
	return doQuery (sqlString, new Object[] {fieldContent}, mapping);
}

public static Vector getByFieldVector (ObjectMapping mapping, String fieldName, Object fieldContent) throws DatabaseException, ObjectException {
	return getByFieldVector (mapping, fieldName, fieldContent, "");
}

public static Vector getByFieldVector (ObjectMapping mapping, String fieldName, Object fieldContent, String appendedSqlString) throws DatabaseException, ObjectException {
	String columnName = mapping.mapFieldName (fieldName);
	String sqlString = "SELECT * FROM "+mapping.getTableName()+" WHERE "+columnName+"=? "+appendedSqlString+";";

	return doQueryVector (sqlString, new Object[] {fieldContent}, mapping);
}

public static StorableObject[] getByWhereClause (ObjectMapping mapping, String whereClause) throws DatabaseException, ObjectException {
    
	String sqlString = "SELECT * FROM "+mapping.getTableName()+" WHERE "+whereClause+";";
        
	return doQuery (sqlString, new Object[] {}, mapping);
}

public static Vector getByWhereClauseVector (ObjectMapping mapping, String whereClause) throws DatabaseException, ObjectException {
	String sqlString = "SELECT * FROM "+mapping.getTableName()+" WHERE "+whereClause+";";

	return doQueryVector (sqlString, new Object[] {}, mapping);
}

public static void handleException (Exception e) {
	System.out.println (e);
	e.printStackTrace ();
}

public static boolean init (Properties properties) throws DatabaseException {
        return init(properties,false);
}
public static boolean init (Properties properties,boolean force) throws DatabaseException {
        	
	try {
                databaseURLPrefix = properties.getProperty ("databaseURLPrefix");
		databaseHost = properties.getProperty ("databaseHost");
		databaseHostPort = properties.getProperty ("databaseHostPort");
		databaseName = properties.getProperty ("databaseName");
                databaseName = databaseName.toLowerCase();
                
        	if (hdbs.containsKey(databaseName)){
                    System.out.println("Already:" + databaseName);	
                    return true;
                }

                driverName = properties.getProperty ("driverName");
		username = properties.getProperty ("username");
		password = properties.getProperty ("password");
		
                System.out.println("dbname:" + databaseName);
                
		int minConnections = new Integer (properties.getProperty ("minConnections")).intValue ();
		int maxConnections = new Integer (properties.getProperty ("maxConnections")).intValue ();
		double maxConnectionTime = new Double (properties.getProperty ("maxConnectionTime")).doubleValue ();
		String logFilePath = properties.getProperty ("logFilePath");
		//System.out.println("after logfilepath");
		String databaseURL = databaseURLPrefix +
                                        databaseHost + ":" +
                                        databaseHostPort + "/" +
                                        databaseName;			
		//System.out.println("after dburl");                                                                                                 
		DbConnectionBroker tdbc = new DbConnectionBroker(driverName, 
                                                            databaseURL, 
                                                            username, 
                                                            password, 
                                                            minConnections, 
                                                            maxConnections, 
                                                            logFilePath, 
                                    maxConnectionTime);
               // System.out.println("after dbconbroker");                                                                                                 
                if(hdbs == null)
                    hdbs = new Hashtable();
                hdbs.put(databaseName.toLowerCase(),tdbc);

	}
	catch (Exception e) {
            e.printStackTrace();
		handleException (e);
	  throw new DatabaseException (e.toString ());
	}
	
	initialized	 = true;
	return true;
}



public static long insert (ObjectMapping mapping, Object[] parameters) throws DatabaseException {
	long id = -1;
        
	String updateString = mapping.getSQLInsertString ();
        
	try {
                
                Connection connection = ((DbConnectionBroker)hdbs.get(mapping.getDatabaseName().toLowerCase())).getConnection ();

		PreparedStatement statement = prepareStatement (connection, updateString, parameters);

		ResultSet resultSet;
		statement.executeUpdate ();

		statement.close ();
		((DbConnectionBroker)hdbs.get(mapping.getDatabaseName().toLowerCase())).freeConnection (connection);
	}
	catch (SQLException e) {
	  handleException (e);
	  throw new DatabaseException (e.toString ());
	}

	return id;
}

public static boolean isInitialized() {
	return initialized;
}

private static PreparedStatement prepareStatement (Connection connection, String sqlString, Object[] parameters) throws SQLException {
	PreparedStatement statement = connection.prepareStatement (sqlString);
	    
	statement.clearParameters ();
	for (int i = 0; i < parameters.length; i++) {
             //System.out.println("This Par " + i + parameters[i]);  
		if (parameters[i] instanceof String) {
			statement.setString(i+1, (String) parameters[i]);
		}
		else if (parameters[i] instanceof Integer) {
			statement.setInt(i+1, ((Integer) parameters[i]).intValue());
		}
		else if (parameters[i] instanceof Long) {
			statement.setLong(i+1, ((Long) parameters[i]).longValue());
		}
		else if (parameters[i] instanceof Float) {
			statement.setFloat(i+1, ((Float) parameters[i]).floatValue());
		}
		else if (parameters[i] instanceof Double) {
			statement.setDouble(i+1, ((Double) parameters[i]).doubleValue());
                }
		else if (parameters[i] instanceof Boolean) {
			statement.setBoolean(i+1, ((Boolean) parameters[i]).booleanValue());
                               
		}
                else if (parameters[i] instanceof java.sql.Timestamp) {
			statement.setTimestamp(i+1, (java.sql.Timestamp) parameters[i]);
		}
                else if (parameters[i] instanceof java.sql.Date) {
			statement.setDate(i+1, (java.sql.Date) parameters[i]);
		}
	
		else {
			statement.setObject(i+1, parameters[i]);
		}
	}
	
	return statement;
}

private static void setFields (StorableObject object, FieldMapping[] fieldMappingList, ResultSet resultSet) throws SQLException, IllegalAccessException, InvocationTargetException {
	for (int i = 0; i < fieldMappingList.length; i++) {
            
		Class fieldClass = fieldMappingList[i].fieldClass;
		
		if (fieldClass == String.class) {
			String string = resultSet.getString (fieldMappingList[i].columnName);				
			fieldMappingList[i].setMethod.invoke (object, new Object[]{string});
		}
		
		if (fieldClass == Integer.TYPE) {
			int intValue = resultSet.getInt (fieldMappingList[i].columnName);				
			fieldMappingList[i].setMethod.invoke (object, new Object[]{new Integer (intValue)});
		}
		
		if (fieldClass == Long.TYPE) {
			long longValue = resultSet.getLong (fieldMappingList[i].columnName);				
			fieldMappingList[i].setMethod.invoke (object, new Object[]{new Long (longValue)});
		}
		
		if (fieldClass == Float.TYPE) {
			float floatValue = resultSet.getFloat (fieldMappingList[i].columnName);				
			fieldMappingList[i].setMethod.invoke (object, new Object[]{new Float (floatValue)});
		}
		
		if (fieldClass == Double.TYPE) {
			double doubleValue = resultSet.getDouble (fieldMappingList[i].columnName);				
			fieldMappingList[i].setMethod.invoke (object, new Object[]{new Double (doubleValue)});
		}
                if (fieldClass == Boolean.TYPE) {
			boolean booleanValue = resultSet.getBoolean (fieldMappingList[i].columnName);				
			fieldMappingList[i].setMethod.invoke (object, new Object[]{new Boolean (booleanValue)});
		}
		
		if (fieldClass == java.sql.Date.class) {
			java.sql.Date dateValue = resultSet.getDate (fieldMappingList[i].columnName);				
			fieldMappingList[i].setMethod.invoke (object, new Object[]{dateValue});
		}
                
                if (fieldClass == java.sql.Timestamp.class) {
			java.sql.Timestamp timeValue = resultSet.getTimestamp (fieldMappingList[i].columnName);				
			fieldMappingList[i].setMethod.invoke (object, new Object[]{timeValue});
		}
	}
}

public static boolean update (ObjectMapping mapping, Object[] parameters) throws DatabaseException {

	String updateString = mapping.getSQLUpdateString();
	try {
                //System.out.println(updateString);
		Connection connection = ((DbConnectionBroker)hdbs.get(mapping.getDatabaseName().toLowerCase())).getConnection ();
		
		PreparedStatement statement = prepareStatement (connection, updateString, parameters);
                
		ResultSet resultSet;
                
		statement.executeUpdate ();

		statement.close ();
		((DbConnectionBroker)hdbs.get(mapping.getDatabaseName().toLowerCase())).freeConnection (connection);
	}
	catch (Exception e) {
            e.printStackTrace();
	  handleException (e);
	  throw new DatabaseException (e.toString ());
	}

	return true;
}
}
