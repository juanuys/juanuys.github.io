package org.gjt.tw.dbobjects.test;

/*
 * DB Objects
 *
 * Copyright (C) 2000 Tim Wellhausen <Tim.Wellhausen@gmx.de>
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 *
 * See the COPYING file located in the top-level-directory of
 * the archive of this library for complete text of license.
 */

/*
 * Project  : DB Objects
 * Package  : dbobjects.test
 * Class    : TestApplication
 * Purpose  : Test application for database management
 * Created  : March 25, 2000
 * Modified : August 21, 2000
 */

import org.gjt.tw.dbobjects.*;
import java.util.*;
import java.io.*;

/**
 * This class is a test application for the package databasemanagement. Currently, it contains
 * two test classes (Address and Customer) and a test application. This test was designed for
 * the database MySQL, because it uses its feature auto_increment to create unique IDs for
 * Address. A script to create the database tables is part of the distribution.
 *
 * @author Tim Wellhausen, <a href="mailto:Tim.Wellhausen@gmx.de">Tim.Wellhausen@gmx.de</a>.
 * @version 0.29
 */
public class TestApplication {
/**
 * Main method of test application.
 *
 * @param args doesn't take any arguments
 */
public static void main(String args[]) {

	// Loading properties
	Properties properties = new Properties();
	try {
		properties.load(new FileInputStream("dbobjects.properties"));
	}
	catch (FileNotFoundException f) {
		System.out.println ("Error during loading of properties: File not found!");
		System.exit (-1);	
	}
	catch (IOException e) {
		System.out.println ("Error during loading of properties: IOException!");
		System.exit (-1);	
	}


	// Initialize database connection broker	
	try {
		DBManager.init (properties);
	}
	catch (DatabaseException e) {
		System.out.println ("Error during initializing of connection to database:\n"+e);
		System.exit (-1);
	}


	// Initialization of storable objects.
	try {
		Customer.init ();
		Address.init ();
		CustomerAddress.init ();
	}
	catch (IncompleteDefinitionException e) {
		System.out.println ("Definition of object mapping is not complete!");
		System.exit (-1);
	}
	catch (ObjectException e) {
		System.out.println ("Definition of object mapping is inconsistent with data structure!");
		System.exit (-1);
	}

	
	// Do some tests.
	try {
		Customer customer = new Customer ();
		customer.setName ("Test Name");
		customer.setPassword ("Test password");
		customer.store ();
		customer.print ();
		
		Address address = new Address ();
		address.setCity ("This town");
		address.setZip ("12345");
		address.setCountry ("My Country");
		address.store ();
		address.print ();

		new CustomerAddress (customer, address).store ();
		
		customer.setCurrentAddress (address);
		customer.setPassword ("New Password");
		customer.store ();
		customer.print ();

		address = new Address ();
		address.setCity ("That town");
		address.setZip ("54321");
		address.setCountry ("Another Country");
		address.store ();
		address.print ();

		new CustomerAddress (customer, address).store ();		

		System.out.println ("\nThe customer and its current address as stored in the database:");
		
		customer = Customer.getByName ("Test Name");
		address = customer.getCurrentAddress ();
		customer.print ();
		address.print ();
		
		System.out.println ("\nAll addresses of that customer:");
			
		Address[] addresses = customer.getAddressList ();
		for (int i = 0; i < addresses.length; i++) {
			addresses[i].print ();
		}

		System.out.println ("\nDeleting all objects...");

		CustomerAddress[] relation = CustomerAddress.getByCustomer (customer);
		for (int i = 0; i < relation.length; i++) {
			relation[i].delete ();
		}	
		for (int i = 0; i < addresses.length; i++) {
			addresses[i].delete ();
		}
		customer.delete ();
		
		System.out.println ("\nDone!");
	}
	catch (Exception e) {
		System.out.println (e);
		System.exit (-1);
	}

	
	// Shut down database connection broker	
	try {
		DBManager.destroy ();
	}
	catch (Exception e) {
		System.out.println ("Error during destruction of database connectivity!");
		System.exit (-1);
	}
}
}
