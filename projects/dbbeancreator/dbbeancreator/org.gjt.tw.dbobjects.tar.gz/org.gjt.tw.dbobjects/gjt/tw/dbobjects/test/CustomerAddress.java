package org.gjt.tw.dbobjects.test;

/*
 * DB Objects
 *
 * Copyright (C) 2000 Tim Wellhausen <Tim.Wellhausen@gmx.de>
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 *
 * See the COPYING file located in the top-level-directory of
 * the archive of this library for complete text of license.
 */

/*
 * Project  : DB Objects
 * Package  : dbobjects.test
 * Class    : CustomerAddress
 * Purpose  : Test object containing data n-m relation between customers and addresses
 * Created  : March 15, 2000
 * Modified : August 21, 2000
 */

import org.gjt.tw.dbobjects.*;
 
/**
 * This class represents a n-m relation between customers and addresses. It doesn't have
 * any attributes of its own right now, but could easily be enhanced.
 *
 * @author Tim Wellhausen, <a href="mailto:Tim.Wellhausen@gmx.de">Tim.Wellhausen@gmx.de</a>.
 * @version 0.29
 */
public class CustomerAddress extends StorableObject {
	private static ObjectMapping mapping;
	private String customerName;
	private long addressId;
/**
 * CustomerAddress constructor comment.
 */
public CustomerAddress() {
	super();
}
/**
 * CustomerAddress constructor comment.
 */
public CustomerAddress(Customer customer, Address address) {
	super();
	customerName = customer.getName ();
	addressId = address.getId ();
}
/**
 * This method was created in VisualAge.
 * @return long
 */
public long getAddressId() {
	return addressId;
}
/**
 * This method was created in VisualAge.
 * @return dbobjects.test.CustomerAddress[]
 * @param customer dbobjects.test.Customer
 */
public static CustomerAddress[] getByCustomer (Customer customer) throws DatabaseException, ObjectException {
	return (CustomerAddress[]) DBManager.getByField (mapping, "customerName", customer.getName ());
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getCustomerName() {
	return customerName;
}
/**
 * Returns object mapping.
 *
 * @return databasemanagement2.ObjectMapping
 */
protected ObjectMapping getMapping() {
	if (mapping == null)
		mapping = new ObjectMapping ();
	return mapping;
}
/**
 * Initialization of object mapping. Has to be called once before first use.
 */
public static void init () throws ObjectException, IncompleteDefinitionException {
	mapping = new ObjectMapping ();
	mapping.setTableName ("customer_address");
	mapping.setObjectClass (CustomerAddress.class);
	mapping.addField ("customerName", String.class, "customer_name");
	mapping.addField ("addressId", Long.TYPE, "address_id");
	mapping.setKeyField ("addressId");
	mapping.useMySQLAutoIncrement (false);
	mapping.prepareSQLStatements ();
}
/**
 * This method was created in VisualAge.
 * @param newValue long
 */
public void setAddressId(long newValue) {
	this.addressId = newValue;
}
/**
 * This method was created in VisualAge.
 * @param newValue java.lang.String
 */
public void setCustomerName(String newValue) {
	this.customerName = newValue;
}
}
