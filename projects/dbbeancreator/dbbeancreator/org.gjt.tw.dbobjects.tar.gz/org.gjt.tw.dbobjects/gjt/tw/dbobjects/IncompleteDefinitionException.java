package org.gjt.tw.dbobjects;

/*
 * DB Objects
 *
 * Copyright (C) 2000 Tim Wellhausen <Tim.Wellhausen@gmx.de>
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 *
 * See the COPYING file located in the top-level-directory of
 * the archive of this library for complete text of license.
 */

/*
 * Project  : DB Objects
 * Package  : org.gjt.tw.dbobjects
 * Class    : IncompleteDefinitionException
 * Purpose  : Is thrown if the definition of an object mapping is incomplete.
 * Created  : March 15, 2000
 * Modified : August 21, 2000
 */
 
/**
 * An IncompleteDefinitionException is thrown if the definition of an object mapping is not complete. 
 * This indicates a bug in the source code.
 *
 * @author Tim Wellhausen, <a href="mailto:Tim.Wellhausen@gmx.de">Tim.Wellhausen@gmx.de</a>.
 * @version 0.29
 */
public class IncompleteDefinitionException extends Exception {
/**
 * DatabaseException constructor comment.
 */
public IncompleteDefinitionException() {
	super();
}
/**
 * DatabaseException constructor comment.
 * @param s java.lang.String
 */
public IncompleteDefinitionException(String s) {
	super(s);
}
}
