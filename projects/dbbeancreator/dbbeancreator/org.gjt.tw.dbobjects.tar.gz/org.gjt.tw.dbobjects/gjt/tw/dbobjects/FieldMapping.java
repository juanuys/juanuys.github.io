package org.gjt.tw.dbobjects;

/*
 * DB Objects
 *
 * Copyright (C) 2000 Tim Wellhausen <Tim.Wellhausen@gmx.de>
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 *
 * See the COPYING file located in the top-level-directory of
 * the archive of this library for complete text of license.
 */

/*
 * Project  : DB Objects
 * Package  : org.gjt.tw.dbobjects
 * Class		: FieldMapping
 * Purpose  : Wrapper for data about the mapping between a field of an object and 
 *            a database column.
 * Created  : March 15, 2000
 * Modified : August 21, 2000
 *
 * @author Tim Wellhausen
 * @version 0.29
 */

import java.lang.reflect.*;

/**
 * FieldMapping is a wrapper class that holds data about the mapping of one field.
 *
 * @author Tim Wellhausen, <a href="mailto:Tim.Wellhausen@gmx.de">Tim.Wellhausen@gmx.de</a>.
 * @version 0.26
 */
public class FieldMapping {
	public String fieldName;
	public Method setMethod;
	public Method getMethod;
	public Class fieldClass;
	public String columnName;
/**
 * Constructor.
 *
 * @param fieldName name of the variable that should be stored in the database.
 * @param setMethod Method that is called to set the content of the variable in the object.
 * @param getMethod Method that is called to get the content of the object's variable.
 * @param fieldClass class of the object that is set and gotten. 
 * @param columnName name of the column in the database that is associated with this mapping.
 */
public FieldMapping(String fieldName, Method setMethod, Method getMethod, Class fieldClass, String columnName) {
	this.fieldName = fieldName;
	this.setMethod = setMethod;
	this.getMethod = getMethod;
	this.fieldClass = fieldClass;
	this.columnName = columnName;
}
}
