package org.gjt.tw.dbobjects;

/*
 * DB Objects
 *
 * Copyright (C) 2000 Tim Wellhausen <Tim.Wellhausen@gmx.de>
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 *
 * See the COPYING file located in the top-level-directory of
 * the archive of this library for complete text of license.
 */

/*
 * Project  : DB Objects
 * Package  : org.gjt.tw.dbobjects
 * Class		: ObjectMapping
 * Purpose  : Contains all necessary data about the mapping between an object and a database table.
 * Created  : March 15, 2000
 * Modified : August 21, 2000
 *
 * @author Tim Wellhausen
 * @version 0.29
 */

import java.lang.reflect.*;
import java.util.*;

/**
 * This class provides all necessary information for the mapping of all objects of a class.
 * For each class to be mapped an object of this class has to be created and initialized.
 * This typically happens inside a static .init() method of that class (see examples in
 * test package).
 *
 * @author Tim Wellhausen, <a href="mailto:Tim.Wellhausen@gmx.de">Tim.Wellhausen@gmx.de</a>.
 * @version 0.26
 */
public class ObjectMapping {
	private Class objectClass;
        private String databaseName = "";
	private String tableName;
	private Vector fieldMappingVector;
	private FieldMapping[] fieldMappingList;
	private String keyFieldName;
	private int keyFieldNumber;
	private String sqlInsertString;
	private String sqlUpdateString;
	private String sqlDeleteString;
	private boolean useMySQLAutoIncrement = false;
	private boolean isCashable = false;

	private Hashtable fieldMappingHashtable;
	private boolean prepared = false;
/**
 * ObjectMapping constructor.
 */
public ObjectMapping() {
	fieldMappingVector = new Vector ();
}
/**
 * This method adds one of the object's fields to the fields that are mapped.
 * Three statements are necessary: the name of the object's field, the class of the
 * field (for example Integer.class, int.TYPE, java.sql.Date.class), and the
 * corresponding column in the database.
 *
 * @param fieldName name of the field
 * @param fieldClass class of the field
 * @param columnName name of the corresponding database column
 */
public void addField (String fieldName, Class fieldClass, String columnName) throws ObjectException {
	if (prepared)
		return;
		
	try {
		String methodName = Character.toUpperCase (fieldName.charAt(0))+fieldName.substring (1);
		Method fieldSetMethod = objectClass.getMethod ("set"+methodName, new Class[] {fieldClass});
		Method fieldGetMethod = objectClass.getMethod ("get"+methodName, new Class[] {});

		fieldMappingVector.addElement (new FieldMapping (fieldName, fieldSetMethod, fieldGetMethod, fieldClass, columnName));
	}
	catch (NoSuchMethodException e) {
		DBManager.handleException (e);
		throw new ObjectException (e.toString ());	
	}
}
/**
 * This method is only used internally. It returns the list of all field mappings.
 *
 * @return databasemanagement2.FieldMapping[]
 */
public FieldMapping[] getFieldMappingList () {	
	return fieldMappingList;
}
/**
 * This method is only used internally. It returns the internal number of the field 
 * that holds the key.
 *
 * @return int
 */
public int getKeyFieldNumber () {
	return keyFieldNumber;
}
/**
 * This method is only used internally. It returns the class of the object to be mapped.
 *
 * @return java.lang.Class
 */
public Class getObjectClass() {
	return objectClass;
}
/**
 * This method is only used internally. It returns the generated SQL string to delete
 * an entry in the database.
 *
 * @return java.lang.String
 */
public String getSQLDeleteString () {
	return sqlDeleteString;
}
/**
 * This method is only used internally. It returns the prepated SQL string to insert a
 * new entry into the database.
 *
 * @return java.lang.String
 */
public String getSQLInsertString () {
	return sqlInsertString;
}
/**
 * This method is only used internally. It returns the prepared SQL string needed to update
 * an existing entry in the database.
 *
 * @return java.lang.String
 */
public String getSQLUpdateString () {
	return sqlUpdateString;
}
/**
 * This method is only used internally. It returns the name of the database  in which
 * all objects of the current class are stored.
 *
 * @return java.lang.String
 */
public String getDatabaseName() {
	return databaseName;
}
/**
 * This method is only used internally. It returns the name of the database table in whic
 * all objects of the current class are stored.
 *
 * @return java.lang.String
 */
public String getTableName() {
	return tableName;
}
/**
 * This method is only used internally. It returns whether the MySQL auto_increment feature
 * is used.
 *
 * @return bolean
 */
public boolean isMySQLAutoIncrementUsed () {
	return useMySQLAutoIncrement;
}
/**
 * This method is only used internally. It provides the mapping between the name of a field
 * and the column of a database table.
 *
 * @return java.lang.String
 * @param fieldName java.lang.String
 */
public String mapFieldName (String fieldName) {
	return (String) fieldMappingHashtable.get (fieldName);
}
/**
 * At the end of initialization this method has to be called. It generates the 
 * needed SQL statements for the internal processing of storing, updating, and 
 * retrieving of the object's data.
 */
public void prepareSQLStatements () throws IncompleteDefinitionException {
	if (prepared)
		return;

	// Check for incomplete definitions.
	if (keyFieldName == null)
		throw new IncompleteDefinitionException ("The key is not defined!");
	if (objectClass == null)
		throw new IncompleteDefinitionException ("The class of the storable object is not defined!");
	if (tableName == null)
		throw new IncompleteDefinitionException ("The table name is not defined");

	// Create array of field mappings
	fieldMappingList = new FieldMapping [fieldMappingVector.size ()];
	fieldMappingVector.copyInto (fieldMappingList);

	// Create hashtable for fast mapping between field names and column names.
	fieldMappingHashtable = new Hashtable ();
	for (int i = 0; i < fieldMappingList.length; i++)
		fieldMappingHashtable.put (fieldMappingList[i].fieldName, fieldMappingList[i].columnName);

	// Check whether there is a mapping for the key
	for (int i = 0; i < fieldMappingList.length; i++)
		if (keyFieldName.equals(fieldMappingList[i].fieldName))
			keyFieldNumber = i;
	if (keyFieldNumber == -1)
		throw new IncompleteDefinitionException ("The mapping for the key is not defines!");
			
	// Create SQL insert string
        /*
	sqlInsertString = "INSERT INTO "+tableName+" SET ";
	for (int i = 0; i < fieldMappingList.length; i++) {
		if (i > 0)
			sqlInsertString += ", ";
		sqlInsertString += fieldMappingList[i].columnName+"=";
		if (useMySQLAutoIncrement && i == keyFieldNumber)
			sqlInsertString += "NULL";
		else
			sqlInsertString += "?";
	}
	sqlInsertString += ";";

         */
        sqlInsertString = "INSERT INTO "+tableName+" ( ";
        String inVal = "";
        String myVal = "";
	for (int i = 0; i < fieldMappingList.length; i++) {
		if (i > 0){
			inVal  += ", ";
                        myVal  += ", ";
                }        
		inVal += fieldMappingList[i].columnName;
		if (useMySQLAutoIncrement && i == keyFieldNumber)
			myVal += "NULL";
		else
			myVal += "?";
	}
        sqlInsertString += inVal + ")" + " values(" + myVal+ ")";
	sqlInsertString += ";";

        
        
	// Create SQL update string
	sqlUpdateString = "UPDATE "+tableName+" SET ";
	boolean first = true;
	for (int i = 0; i < fieldMappingList.length; i++) {
		if (i == keyFieldNumber)
			continue;
		if (!first)
			sqlUpdateString += ", ";
		else
			first = false;
		sqlUpdateString += fieldMappingList[i].columnName+"=?";
	}
	sqlUpdateString += " WHERE "+mapFieldName(keyFieldName)+"=?;";

	// Create SQL delete string
	sqlDeleteString = "DELETE FROM "+tableName+" WHERE "+mapFieldName(keyFieldName)+"=?;";	

	prepared = true;
}
/**
 * Not yet implemented! Sets whether objects that are created from a database should be kept 
 * in an internal cache.
 *
 * @param isCashable boolean
 */
private void setCashable (boolean isCashable) {
	if (prepared)
		return;
	this.isCashable = isCashable;
}
/**
 * Defines the field that is the key of an database entry. This field is defined by its
 * java field name.
 *
 * @param fieldName java.lang.String
 */

public void setKeyField (String keyFieldName) {
	if (prepared)
		return;
	this.keyFieldName = keyFieldName;
}
/**
 * Sets the class of the object. If you want to store an object like String, Integer, etc
 * you have to use .class to determine the class of that object: String.class, Integer.class.
 * To store a type like int, long, etc you have to use .TYPE: Integer.TYPE, Long.TYPE.
 *
 * @param newValue java.lang.Class
 */
public void setObjectClass(Class newValue) {
	if (prepared)
		return;
	this.objectClass = newValue;
}
/**
 * Sets the name of the database in which objects are stored.
 *
 * @param newValue java.lang.String
 */
public void setDatabaseName(String newValue) {
if (prepared)
	return;
	this.databaseName = newValue;
}
/**
 * Sets the name of the database table in which objects are stored.
 *
 * @param newValue java.lang.String
 */
public void setTableName(String newValue) {
if (prepared)
	return;
	this.tableName = newValue;
}
/**
 * Defines whether MySQL's auto_increment feature has to be used. If it is used
 * the org.gjt.mm.mysql jdbs drivers must be used, because the ResultSet retrieved
 * from the database is cast to org.gjt.mm.mysql.ResultSet to get the automatically
 * created ID.
 * <p>
 * If this feature is used the key must be an int or long field and the table has
 * to be created with auto_increment as a parameter for the key value.
 * <p>
 * See the examples in the test package for how to use this feature.
 *
 * @param useIt boolean
 */
public void useMySQLAutoIncrement (boolean useIt) {
	if (prepared)
		return;
	useMySQLAutoIncrement = useIt;
}
}
